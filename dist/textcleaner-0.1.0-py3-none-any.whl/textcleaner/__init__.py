from .cleaner import clean_text  # Expose the main function
__version__ = "0.1.0"